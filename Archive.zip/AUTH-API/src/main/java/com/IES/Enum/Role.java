package com.IES.Enum;

public enum Role {
	
	User,Citizen

}
