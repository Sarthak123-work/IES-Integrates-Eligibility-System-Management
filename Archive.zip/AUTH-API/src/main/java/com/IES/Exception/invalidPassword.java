package com.IES.Exception;

public class invalidPassword extends RuntimeException {

	public invalidPassword(String s) {
		super(s);
	}
}
