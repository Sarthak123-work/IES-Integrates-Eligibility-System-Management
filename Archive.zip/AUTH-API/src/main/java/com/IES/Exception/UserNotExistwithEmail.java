package com.IES.Exception;

public class UserNotExistwithEmail extends RuntimeException {
	
	public UserNotExistwithEmail(String s) {
		super(s);
	}

}
