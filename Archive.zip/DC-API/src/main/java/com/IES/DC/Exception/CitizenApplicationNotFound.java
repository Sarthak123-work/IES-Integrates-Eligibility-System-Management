package com.IES.DC.Exception;

public class CitizenApplicationNotFound extends RuntimeException {

	public CitizenApplicationNotFound(String msg) {
		super(msg);
	}
}
