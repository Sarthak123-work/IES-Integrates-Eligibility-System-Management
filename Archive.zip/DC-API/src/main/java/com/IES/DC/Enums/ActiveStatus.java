package com.IES.DC.Enums;

public enum ActiveStatus {

	Y, N
}
