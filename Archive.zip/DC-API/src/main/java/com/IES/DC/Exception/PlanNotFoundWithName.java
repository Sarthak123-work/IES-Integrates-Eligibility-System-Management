package com.IES.DC.Exception;

public class PlanNotFoundWithName extends RuntimeException {

	public PlanNotFoundWithName(String msg) {
		super(msg);
	}
}
