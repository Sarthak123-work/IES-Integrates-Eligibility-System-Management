package com.IES.DC.Enums;

public enum Role {

	Admin, Citizen
}
