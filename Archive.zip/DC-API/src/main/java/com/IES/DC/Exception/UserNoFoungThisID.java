package com.IES.DC.Exception;

public class UserNoFoungThisID extends RuntimeException {

	public UserNoFoungThisID(String msg) {
		super(msg);
	}
}
