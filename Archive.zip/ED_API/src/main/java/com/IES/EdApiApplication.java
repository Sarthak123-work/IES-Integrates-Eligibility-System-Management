package com.IES;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdApiApplication.class, args);
	}

}
