package com.IES.Enum;

public enum Role 
{
  Admin,Citizen
}
