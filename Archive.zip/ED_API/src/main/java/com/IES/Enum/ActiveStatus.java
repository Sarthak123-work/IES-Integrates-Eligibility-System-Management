package com.IES.Enum;

public enum ActiveStatus 
{
  Y,N
}
