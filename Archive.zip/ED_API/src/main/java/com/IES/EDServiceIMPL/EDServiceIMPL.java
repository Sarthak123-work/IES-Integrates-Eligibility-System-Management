package com.IES.EDServiceIMPL;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.IES.DTO.EdResponseDTO;
import com.IES.Entity.CitizenApplication;
import com.IES.Entity.DCEducation;
import com.IES.Entity.DCIncome;
import com.IES.Entity.DCKid;
import com.IES.Entity.EligibilityDetermination;
import com.IES.Repo.CitizenApplicationRepo;
import com.IES.Repo.EDRepo;
import com.IES.Repo.EducationRepo;
import com.IES.Repo.IncomeRepo;
import com.IES.Repo.KidRepo;
import com.IES.Service.EDService;
import com.IES.Service.S3Service;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class EDServiceIMPL implements EDService 
{
	@Autowired
    private CitizenApplicationRepo citizenRepo;
    @Autowired
    private IncomeRepo incomeRepo;
    @Autowired
    private EducationRepo educationRepo;
    @Autowired
    private KidRepo kidRepo;
    @Autowired
    private EDRepo edRepo;
//    @Autowired
//    private S3Service ss;

    @Override
    public EdResponseDTO determineEligibility(Integer appNumber) {
    	 CitizenApplication app = citizenRepo.findByAppNumber(appNumber)
                 .orElseThrow(() -> new RuntimeException("Application not found"));

         String planName = app.getPlan().getPlanName();
         DCIncome income = incomeRepo.findByCitizenApplicationAppNumber(appNumber);
         DCEducation edu = educationRepo.findByCitizenApplicationAppNumber(appNumber);
         List<DCKid> kids = kidRepo.findByCitizenApplicationAppNumber(appNumber);

         EligibilityDetermination ed = new EligibilityDetermination();
         ed.setCitizenApplication(app);

         // ==========================
         // SNAP (Food Assistance)
         // ==========================
         if ("SNAP".equalsIgnoreCase(planName)) {
             if (income != null && (income.getSalaryIncome() + income.getPropertyIncome()) <= 30000) {
                 ed.setPlanStatus("APPROVED");
                 ed.setBenefitAmount(350.0);
                 ed.setPlanStartDate(LocalDate.now());
                 ed.setPlanEndDate(LocalDate.now().plusMonths(6));
             } else {
                 ed.setPlanStatus("DENIED");
                 ed.setDenialReason("Income too high");
             }
         }

         // ==========================
         // CCAP (Child Care Assistance)
         // ==========================
         else if ("CCAP".equalsIgnoreCase(planName)) {
        	 boolean eligible = kids.stream()
        			    .anyMatch(k -> {
        			        LocalDate dob = LocalDate.parse(k.getKidDob());  // ISO format yyyy-MM-dd
        			        return Period.between(dob, LocalDate.now()).getYears() < 16;
        			    });


             if (eligible) {
                 ed.setPlanStatus("APPROVED");
                 ed.setBenefitAmount(250.0);
                 ed.setPlanStartDate(LocalDate.now());
                 ed.setPlanEndDate(LocalDate.now().plusYears(1));
             } else {
                 ed.setPlanStatus("DENIED");
                 ed.setDenialReason("No kids under 16");
             }
         }

         // ==========================
         // Medicaid
         // ==========================
         else if ("Medicaid".equalsIgnoreCase(planName)) {
             if (income != null && income.getSalaryIncome() <= 2000 && edu != null) {
                 ed.setPlanStatus("APPROVED");
                 ed.setBenefitAmount(500.0);
                 ed.setPlanStartDate(LocalDate.now());
                 ed.setPlanEndDate(LocalDate.now().plusYears(1));
             } else {
                 ed.setPlanStatus("DENIED");
                 ed.setDenialReason("Income too high or education record missing");
             }
         }

         // ==========================
         // Medicare
         // ==========================
         else if ("Medicare".equalsIgnoreCase(planName)) {
             // If dob is LocalDate in CitizenApplication
        	 String dobStr = app.getDob();               // e.g. "2000-05-20"
        	 LocalDate dob = LocalDate.parse(dobStr);    // parse the String to LocalDate

        	 int age = Period.between(dob, LocalDate.now()).getYears();

             if (age >= 65) {
                 ed.setPlanStatus("APPROVED");
                 ed.setBenefitAmount(800.0);
                 ed.setPlanStartDate(LocalDate.now());
                 ed.setPlanEndDate(LocalDate.now().plusYears(1));
             } else {
                 ed.setPlanStatus("DENIED");
                 ed.setDenialReason("Applicant age less than 65");
             }
         }
         
         else if("QHP".equalsIgnoreCase(planName)) {
        	 ed.setPlanStatus("Approved.Contact with your Vendor from you have taken Insurance.");
             ed.setBenefitAmount(0.0);
             ed.setPlanStartDate(LocalDate.now());
             ed.setPlanEndDate(LocalDate.now().plusYears(1));
         }

         edRepo.save(ed);

         return new EdResponseDTO(
        		 appNumber,
                 planName,
                 ed.getPlanStatus(),
                 ed.getBenefitAmount(),
                 ed.getDenialReason()
         );
    }
         @Override
         public void generatePDF() 
         {
        	 List<EdResponseDTO> reportData = new ArrayList<>();

        	// SNAP
        	reportData.add(new EdResponseDTO(1001, "SNAP", "APPROVED", 350.0, null));

        	// CCAP
        	reportData.add(new EdResponseDTO(1002, "CCAP", "DENIED", 0.0, "No kids under 16"));

        	// Medicaid
        	reportData.add(new EdResponseDTO(1003, "Medicaid", "APPROVED", 500.0, null));
        	reportData.add(new EdResponseDTO(1004, "Medicaid", "DENIED", 0.0, "Income too high"));

        	// Medicare
        	reportData.add(new EdResponseDTO(1005, "Medicare", "APPROVED", 800.0, null));
        	reportData.add(new EdResponseDTO(1006, "Medicare", "DENIED", 0.0, "Applicant age less than 65"));

        	// QHP (Qualified Health Plan)
        	reportData.add(new EdResponseDTO(1007, "QHP", "APPROVED", 450.0, null));
        	reportData.add(new EdResponseDTO(1008, "QHP", "DENIED", 0.0, "Not eligible for coverage"));
         try {
             // Load JRXML template
             InputStream reportStream = getClass().getResourceAsStream("/ed_report.jrxml");
             if (reportStream == null) {
                 throw new RuntimeException("Report file not found in classpath: ed_report.jrxml");
             }
             JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

             // Parameters
             Map<String, Object> params = new HashMap<>();
             params.put("createdBy", "ED Module");

             // DataSource
             JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(reportData);

             // Fill report
             JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, dataSource);

             // Export to local PDF file
             String filePath = "/Users/sarthakjagtap/Desktop/IES Reports"+"ED_Report_" + System.currentTimeMillis() + ".pdf";
             JasperExportManager.exportReportToPdfFile(jasperPrint, filePath);

             System.out.println("✅ PDF generated locally: " + filePath);

         } catch (Exception e) {
             e.printStackTrace();
             throw new RuntimeException("Failed to generate ED report", e);
         }
	
}
}
