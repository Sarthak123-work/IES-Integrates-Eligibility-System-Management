package com.admin.Enun;

public enum ActiveStatus {
    Y, N
}