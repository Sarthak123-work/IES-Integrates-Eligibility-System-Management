package com.IES;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitizenApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
