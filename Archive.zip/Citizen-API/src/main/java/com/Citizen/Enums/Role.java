package com.Citizen.Enums;

public enum Role {

	Admin, Citizen
}
