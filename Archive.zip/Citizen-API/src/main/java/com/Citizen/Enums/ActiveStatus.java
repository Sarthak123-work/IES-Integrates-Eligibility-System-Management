package com.Citizen.Enums;

public enum ActiveStatus {

	Y, N
}
