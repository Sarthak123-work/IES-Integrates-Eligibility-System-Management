package com.Citizen.Exception;

public class PlanNotFoundWithName extends RuntimeException {

	public PlanNotFoundWithName(String msg) {
		super(msg);
	}
}
